import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import parametries.params;

import java.time.Duration;

public class testChromeBrowser {

    protected WebDriver driver;
    private Logger logger = LogManager.getLogger();


    @Before
    public void StartUp(){
        driver = params.chromeParam();
        logger.info("Драйвер поднят");
    }

    @After
    public void End(){
        if(driver != null){
            driver.quit();
        }
        logger.info("Драйвер закрыт");
    }

    @Test
    public void serachOtusDuck(){
        driver.manage().window().maximize();
        By firstElementDDSearchPage = By.xpath("//*[@id='r1-0']");
        driver.get("https://duckduckgo.com/");
        driver.findElement(By.xpath("//*[@id='search_form_input_homepage']")).sendKeys("ОТУС");
        driver.findElement(By.xpath("//*[@id='search_button_homepage']")).click();
        getElement(firstElementDDSearchPage);
        String actual = driver.findElement(By.xpath("//span[normalize-space()='https://otus.ru']")).getText();
        Assert.assertEquals("https://otus.ru", actual);
    }



    private WebElement getElement(By locator){
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

}
