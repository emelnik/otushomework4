package parametries;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.Locale;
import java.util.Properties;

public class params {

    public static WebDriver chromeParam(){

        String param = System.getProperty("param").trim().toLowerCase(Locale.ENGLISH);

        Properties p = System.getProperties();

        if(p.getProperty("param") != null) {
             param = System.getProperty("param").trim().toLowerCase(Locale.ENGLISH);
        } else {
            WebDriverManager.chromedriver().setup();
            return new ChromeDriver();
        }

        switch (param){

            case "hedless":
                WebDriverManager.chromedriver().setup();
                ChromeOptions optionsHedless = new ChromeOptions();
                optionsHedless.addArguments("headless");
                return new ChromeDriver(optionsHedless);
            case "kiosk":
                WebDriverManager.chromedriver().setup();
                ChromeOptions optionsKiosk = new ChromeOptions();
                optionsKiosk.addArguments("kiosk");
                return new ChromeDriver(optionsKiosk);
            default:
                WebDriverManager.chromedriver().setup();
                return new ChromeDriver();
        }
    }

}
